clear;
close all;

run('/home/haquang/workspace/rtai/haptuator/haptuatorAdaptiveControl/acc.m')
acc_m = data(:,1);
acc_s = data(:,2);
acc_r = data(:,3);

theta1 = data(:,4);
theta2 = data(:,5);
theta3 = data(:,6);
theta4 = data(:,7);
err = data(:,8);

figure(1)
plot(acc_m,'r');
hold on;
plot(acc_s,'--k');
%hold on;
%plot(acc_r,'-b');
%hold on;
%plot(err,'k');

%{
figure(2)
subplot(4,1,1);
plot(theta1,'r');
subplot(4,1,2);
plot(theta2,'k');
subplot(4,1,3);
plot(theta3,'b');
subplot(4,1,4);
plot(theta4,'c');
%}
